#include <iostream>
#include <deque>
#include <limits>
#include "hgraph.h"
// You may add other necessary #includes other than <algorithm>


using namespace std;


HollywoodGraph::HollywoodGraph(int n, vector<string> names)
{

}

HollywoodGraph::~HollywoodGraph()
{

}

bool HollywoodGraph::addConnection(string person1, string person2)
{

}

int HollywoodGraph::countConnections(string person1)
{

}

bool HollywoodGraph::degreesOfSeparation(string person1, string person2, int k, int& calls)
{

}

